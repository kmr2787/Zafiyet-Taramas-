import os
os.system("nmap -p80 --script http-xssed.nse baklavacimehmetyildirim.com yemek.com -sS -sV -oX KamerGözecarpan.xml")
#-sS : syn taraması (Servis)
#-sV : Versiyon tespiti
#-oX : xml çıktı almak

#Nmap kullanımı için bilgi edindiğim kaynak https://nmap.org/nsedoc/scripts/http-xssed.html

#Kaynak olarak kullandığım sayfada kullanılan örnek ise ;
#nmap -p80 --script http-xssed.nse <target>

#This script will search the xssed.com database and it will output any
#results. xssed.com is the largest online archive of XSS vulnerable
#websites.

#PORT   STATE SERVICE REASON
#80/tcp open  http    syn-ack
#http-xssed:
#xssed.com found the following previously reported XSS vulnerabilities marked as unfixed:
#redirect/links.aspx?page=http://xssed.com

#derefer.php?url=http://xssed.com/
#xssed.com found the following previously reported XSS vulnerabilities marked as fixed:
#myBook/myregion.php?targetUrl=javascript:alert(1);